import {LlmAdapter,LlmError} from '@deepseek-ai/dsh-llm';
import {localRequest} from './chat-ui-bridge.js';
import {buildChatPrompt,parseChatReply} from './chat-ui-prompt.js';
export class ChatBrowserAdapter extends LlmAdapter {
  constructor(ctx){super();this.ctx=ctx;}
  providerInfo(provider){return{id:provider,name:'ChatGPT Chat · 本机网页'};}
  async listModels(provider){return[{provider,id:'browser-chat',name:'Chat页面当前选择的模型',inputModalities:['text','image']}];}
  async resolveModel(provider,model){if(model!=='browser-chat')throw new LlmError('请使用专用Chat标签页当前选择的模型。','MODEL_NOT_FOUND');return{provider,id:model,name:'ChatGPT Chat · 网页当前模型',inputModalities:['text','image'],context:{contextWindow:32768},reasoning:{efforts:[{id:'off',name:'Chat页面设置'}],defaultEffort:'off'}};}
  async *stream(options){
    try{
      const request=await buildChatPrompt(options,this.ctx.get('attachments'));
      const response=await localRequest('/generate',{prompt:request.prompt,images:request.images},{signal:options.signal?AbortSignal.any([options.signal,AbortSignal.timeout(155000)]):AbortSignal.timeout(155000)});
      const reply=parseChatReply(response.text,request.nonce,options.tools||[]);
      if(reply.kind==='final'){yield{type:'block-start',index:0,blockType:'text'};yield{type:'text-delta',index:0,text:reply.text};yield{type:'block-end',index:0,block:{type:'text',text:reply.text}};yield{type:'finish',reason:{kind:'stop'}};}
      else{let index=0;for(const call of reply.calls){yield{type:'block-start',index,blockType:'tool-call'};yield{type:'block-end',index,block:{type:'tool-call',...call}};index++;}yield{type:'finish',reason:{kind:'tool-calls'}};}
    }catch(error){if(options.signal?.aborted)throw error;const code=/^CHAT_UI_[A-Z_]+$/.test(error.message)?error.message:'CHAT_UI_REPLY_INVALID';throw new LlmError('Chat网页连接未完成（'+code+'），请查看控制台的Chat页面状态。','PROVIDER_ERROR');}
  }
}
