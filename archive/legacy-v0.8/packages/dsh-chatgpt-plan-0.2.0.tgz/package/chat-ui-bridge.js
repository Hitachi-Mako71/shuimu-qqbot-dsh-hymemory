import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { atomicJson, readJson } from './auth.js';

export const UI_PORT = 8767;
export const uiDirectory = () => process.env.QQBOT_CHAT_UI_DIR || path.resolve('data/chatgpt-chat');
const equal = (a, b) => {if(typeof a!=='string'||typeof b!=='string')return false;const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&timingSafeEqual(x,y);};
export function settings(directory = uiDirectory()) {
  const file = path.join(directory, 'bridge.private.json');
  let value = readJson(file);
  if (!value) {
    value = {ownerToken: randomBytes(32).toString('hex'), extensionToken: randomBytes(32).toString('hex'), extensionId: ''};
    atomicJson(file, value);
  }
  return value;
}
export function localRequest(route, body, {directory = uiDirectory(), signal, token, extensionId} = {}) {
  const owner = token || settings(directory).ownerToken;
  return new Promise((resolve, reject) => {
    const request = http.request({hostname:'127.0.0.1',port:UI_PORT,path:route,method:body === undefined?'GET':'POST',
      headers:{authorization:'Bearer '+owner,...(extensionId?{'x-yuzu-extension':extensionId}:{}),...(body===undefined?{}:{'content-type':'application/json'})},signal},response=>{
      let data='';response.on('data',chunk=>{data+=chunk;if(data.length>12*1024*1024)request.destroy(Error('CHAT_UI_RESPONSE_TOO_LARGE'));});
      response.on('end',()=>{let value;try{value=data?JSON.parse(data):{};}catch{return reject(Error('CHAT_UI_INVALID_RESPONSE'));}
        if(response.statusCode<200||response.statusCode>=300)return reject(Error(value.code||'CHAT_UI_UNAVAILABLE'));resolve(value);});
      response.on('error',reject);
    });request.on('error',()=>reject(Error(signal?.aborted?'CHAT_UI_CANCELLED':'CHAT_UI_OFFLINE')));if(body!==undefined)request.write(JSON.stringify(body));request.end();
  });
}
export async function serve(directory = uiDirectory()) {
  const config=settings(directory), queue=[], active=new Map();let heartbeat={connected:false}, pairing=readJson(path.join(directory,'pairing.private.json'),{});
  const startedAt=Date.now();let attempts=[];
  const finish=(job,result,error)=>{if(!active.has(job.id))return;active.delete(job.id);clearTimeout(job.timer);job.owner.removeListener('close',job.onClose);error?job.send(503,{code:error}):job.send(200,{text:result});};
  const readBody=async request=>{let bytes=0,parts=[];for await(const part of request){bytes+=part.length;if(bytes>12*1024*1024)throw Error('BODY_TOO_LARGE');parts.push(part);}return JSON.parse(Buffer.concat(parts).toString()||'{}');};
  const server=http.createServer(async(request,response)=>{
    const origin=request.headers.origin||'', extension=request.headers['x-yuzu-extension']||'', supplied=(request.headers.authorization||'').replace(/^Bearer /,'');
    const extensionOrigin=/^chrome-extension:\/\/[a-p]{32}$/.test(origin);
    if(origin){if(!extensionOrigin){response.writeHead(403).end();return;}response.setHeader('access-control-allow-origin',origin);response.setHeader('vary','Origin');}
    const send=(status,value)=>{if(response.destroyed||response.writableEnded)return;response.writeHead(status,{'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff'});response.end(JSON.stringify(value));};
    if(request.method==='OPTIONS'){response.writeHead(204,{'access-control-allow-methods':'GET,POST,OPTIONS','access-control-allow-headers':'authorization,content-type,x-yuzu-extension'}).end();return;}
    if(request.method==='GET'&&request.url==='/health')return send(200,{ok:true,service:'yuzu-chat-ui',startedAt,connected:Date.now()-(heartbeat.at||0)<7000&&heartbeat.connected,mode:heartbeat.mode||'unknown',temporary:!!heartbeat.temporary,status:heartbeat.status||'extension-offline',queued:active.size});
    const owner=equal(supplied,config.ownerToken)&&!origin;
    const allowedExtension=equal(supplied,config.extensionToken)&&extension===config.extensionId&&(!origin||origin==='chrome-extension://'+extension);
    if(request.url==='/pair'&&request.method==='POST'){
      attempts=attempts.filter(t=>Date.now()-t<60000);if(attempts.length>=8)return send(429,{code:'PAIR_RATE_LIMIT'});attempts.push(Date.now());
      const body=await readBody(request).catch(()=>({}));pairing=readJson(path.join(directory,'pairing.private.json'),{});
      if(!/^[a-p]{32}$/.test(extension)||origin&&origin!=='chrome-extension://'+extension||pairing.expiresAt<Date.now()||!equal(body.code,pairing.code))return send(403,{code:'PAIR_REJECTED'});
      config.extensionId=extension;atomicJson(path.join(directory,'bridge.private.json'),config);fs.rmSync(path.join(directory,'pairing.private.json'),{force:true});pairing={};return send(200,{token:config.extensionToken});
    }
    if(!owner&&!allowedExtension)return send(401,{code:'UNAUTHORIZED'});
    try{
      if(owner&&request.method==='POST'&&request.url==='/generate'){
        const body=await readBody(request);if(typeof body.prompt!=='string'||body.prompt.length>150000||!Array.isArray(body.images)||body.images.length>6)return send(400,{code:'CHAT_UI_INVALID_INPUT'});
        if(!heartbeat.connected||Date.now()-(heartbeat.at||0)>7000||heartbeat.mode!=='chat'||!heartbeat.temporary)return send(503,{code:'CHAT_UI_NOT_READY'});
        if(active.size>=6)return send(429,{code:'CHAT_UI_BUSY'});
        const job={id:randomUUID(),lease:randomBytes(16).toString('hex'),prompt:body.prompt,images:body.images,send,owner:response,claimed:false,createdAt:Date.now()};
        job.onClose=()=>{if(!response.writableEnded)finish(job,null,'CHAT_UI_CANCELLED');};response.on('close',job.onClose);
        job.timer=setTimeout(()=>finish(job,null,'CHAT_UI_TIMEOUT'),150000);active.set(job.id,job);queue.push(job);return;
      }
      if(allowedExtension&&request.method==='POST'&&request.url==='/poll'){
        const body=await readBody(request);heartbeat={at:Date.now(),connected:body.ready===true,mode:body.mode==='chat'?'chat':body.mode==='work'?'work':'unknown',temporary:body.temporary===true,status:String(body.status||'').slice(0,80)};
        if(!heartbeat.connected||heartbeat.mode!=='chat'||!heartbeat.temporary)return send(200,{});
        if([...active.values()].some(j=>j.claimed))return send(200,{});
        while(queue.length){const job=queue.shift();if(!active.has(job.id))continue;job.claimed=true;return send(200,{job:{id:job.id,lease:job.lease,prompt:job.prompt,images:job.images,expiresAt:job.createdAt+150000}});}return send(200,{});
      }
      if(allowedExtension&&request.method==='POST'&&request.url==='/complete'){
        const body=await readBody(request),job=active.get(body.id);if(!job||!job.claimed||!equal(body.lease,job.lease))return send(409,{code:'CHAT_UI_JOB_EXPIRED'});
        if(body.error)finish(job,null,/^CHAT_UI_[A-Z_]+$/.test(body.error)?body.error:'CHAT_UI_PAGE_FAILED');
        else if(typeof body.text==='string'&&body.text.trim()&&body.text.length<=100000)finish(job,body.text);
        else finish(job,null,'CHAT_UI_EMPTY_REPLY');return send(200,{ok:true});
      }
      if(owner&&request.method==='GET'&&request.url==='/status')return send(200,{paired:!!config.extensionId,...heartbeat});
      send(404,{code:'NOT_FOUND'});
    }catch{send(400,{code:'CHAT_UI_INVALID_INPUT'});}
  });
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(UI_PORT,'127.0.0.1',resolve);});
  atomicJson(path.join(directory,'server.private.json'),{pid:process.pid,script:process.argv[1],startedAt});
  const stop=()=>{for(const job of active.values())finish(job,null,'CHAT_UI_SHUTDOWN');server.closeAllConnections();server.close(()=>process.exit(0));};process.once('SIGTERM',stop);process.once('SIGINT',stop);
  return server;
}
