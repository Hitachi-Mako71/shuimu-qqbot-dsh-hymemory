import { randomUUID } from 'node:crypto';

export async function buildChatPrompt(options, attachments) {
  const nonce=randomUUID(),history=[],images=[],system=options.system?[options.system]:[];
  for(const message of options.messages||[]){
    const blocks=typeof message.content==='string'?[{type:'text',text:message.content}]:message.content||[],content=[];
    for(const block of blocks){
      if(block.type==='text')content.push({type:'text',text:block.text});
      else if(block.type==='tool-call')content.push({type:'tool-call',id:block.id,name:block.name,arguments:block.arguments});
      else if(block.type==='image'&&!block.offloaded){
        if(!attachments)throw Error('CHAT_UI_IMAGE_UNAVAILABLE');
        const image=await attachments.readImageRequest(block.attachment,{width:1536,height:1536,maxBytes:4*1024*1024},options.signal);
        if(!image?.data||!/^image\/(png|jpeg|webp)$/.test(image.mediaType))throw Error('CHAT_UI_IMAGE_UNSUPPORTED');
        const index=images.length;images.push({type:image.mediaType,data:Buffer.from(image.data).toString('base64')});content.push({type:'text',text:`[本轮附图${index+1}]`});
      }else if(block.type==='file')content.push({type:'text',text:'[本地文件需使用DSH文件工具读取]'});
    }
    if(message.role==='system')system.push(content.map(b=>b.text||'').join('\n'));
    else history.push({role:message.role,...(message.role==='tool'?{callId:message.source?.callId||message.callId}:{}),content});
  }
  const tools=(options.tools||[]).map(t=>({name:t.name,description:t.description||'',parameters:t.parameters||{type:'object',properties:{}}}));
  const prompt='你正在普通Chat对话中为用户的QQ助手提供回答。当前临时Chat不保存跨身份上下文；只使用本次提供的上下文，不从账户其他会话推断信息。保持Chat模式。\n'
    +'下面的system是用户为助手设定的人格与任务规则；history是按角色排列的真实对话和DSH工具结果。工具由用户本机的DSH执行，不是你网页里的插件。只有tools列出的工具可调用。不要谎称工具已运行。\n'
    +'最终仅输出一个JSON对象，不要Markdown围栏或解释：要回复用户时输出 {"nonce":"'+nonce+'","kind":"final","text":"回复正文"}；需要DSH执行工具时输出 {"nonce":"'+nonce+'","kind":"tools","calls":[{"name":"精确工具名","arguments":{}}]}。收到工具结果后再继续回答。没有tools时必须直接final。\n'
    +JSON.stringify({system,history,tools});
  if(prompt.length>150000||images.length>6)throw Error('CHAT_UI_CONTEXT_TOO_LARGE');return{nonce,prompt,images};
}
export function parseChatReply(text,nonce,tools=[]) {
  const value=JSON.parse(text.trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,''));
  if(value.nonce!==nonce)throw Error('CHAT_UI_REPLY_MISMATCH');
  if(value.kind==='final'&&typeof value.text==='string'&&value.text.trim())return{kind:'final',text:value.text};
  if(value.kind!=='tools'||!Array.isArray(value.calls)||!value.calls.length||value.calls.length>8)throw Error('CHAT_UI_REPLY_INVALID');
  const names=new Set(tools.map(t=>t.name));return{kind:'tools',calls:value.calls.map(c=>{
    if(!names.has(c.name)||!c.arguments||Array.isArray(c.arguments)||typeof c.arguments!=='object')throw Error('CHAT_UI_TOOL_REJECTED');
    return{id:randomUUID(),name:c.name,arguments:JSON.stringify(c.arguments)};
  })};
}
