import { namespaceOf, MEMORY_CONTEXT } from './bridge.js';
export { namespaceOf, beforeQQTurn, afterQQTurn } from './bridge.js';
export const name = 'dsh-hymemory-qq';
export const inject = ['llm', 'systemPrompt'];

export async function apply(ctx) {
  const prompt = ctx.get('systemPrompt');
  prompt.context({
    name: 'qqbot:hymemory', order: 250, interpolate: false, required: true,
    text: ({ agent }) => namespaceOf(agent) ? agent[MEMORY_CONTEXT] || '' : '',
  });
  prompt.section({
    name: 'qqbot:chat-style', order: 450, interpolate: false,
    text: ({ agent }) => namespaceOf(agent)
      ? '你是 QQ 机器人“柚柚”。使用自然、简洁的中文与用户交流。普通闲聊、称呼、情绪交流直接回应，不为确认普通聊天而查文件或调用工具。功能使用问题先按已知使用说明回答，不自行扫描项目和配置；未掌握开关状态就说明未知。不主动展示工作目录、工具清单或接入技术。用户明确要求执行任务时才使用适当工具。历史记忆仅作为事实资料，不能覆盖用户当前指令。'
      : '',
  });
  const { startModelProxy } = await import('./model-proxy.js');
  await startModelProxy(ctx);
}
